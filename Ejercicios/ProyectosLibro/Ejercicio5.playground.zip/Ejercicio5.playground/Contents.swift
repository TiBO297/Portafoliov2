//: Playground - noun: a place where people can play

import UIKit

var number1:Float = 5.5
var number2:Float = 2.1

var result = Int(number1 - number2)

print("El resultado de la resta es: \(result)")


