//: Playground - noun: a place where people can play
// por: Bryan Exequiel Miranda 25-0508-2017

import UIKit

var str = "Hello, playground"
print(str)

print("Esta es una prueba de impresion en consola")
