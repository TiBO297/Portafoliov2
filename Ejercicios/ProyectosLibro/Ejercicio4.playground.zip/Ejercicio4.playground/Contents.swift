//: Playground - noun: a place where people can play

import UIKit

var number:Float = 1.2

print("Numero elevando al cuadrado: \(pow(number,2))")
