//: Playground - noun: a place where people can play

import UIKit

var number1:Int = 2
var number2:Int = 5
var result:Int = 0

result = number1 * number2

print("El resultado de la multiplicacion es: \(result)")
