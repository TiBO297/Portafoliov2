//: Playground - noun: a place where people can play
//Hecho por: Bryan exequiel Miranda 25-0508-2017

import UIKit

var str = "Hello, playground"

var valor = 0

var valor1 = 1

var valor2 = 5
