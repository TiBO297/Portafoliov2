//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda 25-0508-2017

import UIKit

var valor1 = 4
var valor2 = 5

if(valor1 <= valor2)
{
    print("Si")
}
else
{
    print("No")
}
