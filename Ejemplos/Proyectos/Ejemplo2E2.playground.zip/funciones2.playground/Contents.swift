import UIKit

func getPhrase() -> String{
    return "Hola desde una funcion"
}
print (getPhrase())

func imprimirMensaje(){
    print("Funcion imprime mensaje")
}

imprimirMensaje()

func sumar(Num1:Int, Num2:Int) -> Int {
    var resultado:Int=0
    resultado=Num1+Num2
    return resultado
}

var lasuma:Int=0
lasuma=sumar(Num1: 5, Num2: 6)

