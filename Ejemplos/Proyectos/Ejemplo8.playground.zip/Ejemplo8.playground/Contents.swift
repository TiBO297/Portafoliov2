//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda
import UIKit

for i in 1..<100{
    print("El numero es: \(i)")
}
