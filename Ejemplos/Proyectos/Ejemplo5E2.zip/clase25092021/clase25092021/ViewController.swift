import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var txtValor1:UITextField!
    @IBOutlet weak var txtValor2: UITextField!
    @IBOutlet weak var lblResultado: UILabel!
    @IBOutlet weak var btnCalcular: UIButton!
    @IBOutlet weak var segOpciones: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()}
    @IBAction func calcular(_ sender: UIButton) {
        var valor1:String=""
        var valor2:String=""
        var resultado:Double = 0.00
        var opcionSelected:Int=0
        valor1 = txtValor1.text!
        valor2 = txtValor2.text!
        opcionSelected = segOpciones.selectedSegmentIndex
        if(opcionSelected==0){
            resultado = Double(valor1)! + Double(valor2)!}
        if(opcionSelected==1){
            resultado = Double(valor1)! - Double(valor2)!}
        if(opcionSelected==2){
            resultado = Double(valor1)! * Double(valor2)!}
        if(opcionSelected==3){
            resultado = Double(valor1)! / Double(valor2)!}
        resultado = Double(valor1)! + Double(valor2)!
        lblResultado.text = String(resultado)
    }
    
}

