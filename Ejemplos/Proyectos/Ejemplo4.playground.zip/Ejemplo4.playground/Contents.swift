//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda 25-0508-2017

import UIKit

let a = 1
var firstNumber = 2
var secondNumber = 3
var totalSum = firstNumber + secondNumber

firstNumber = firstNumber + 1
secondNumber =  secondNumber + 1

totalSum = firstNumber + secondNumber

print("totalSum = \(totalSum)")
