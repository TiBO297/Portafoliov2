//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda 25-0508-2017

import UIKit

var valor1:Int = 3
var valor2:Int = 4
var resula:Int = 0 //se asigna el resultado de la operacion

resula=valor1 + valor2

print("La suma de \(valor1) mas \(valor2) es \(resula)")

