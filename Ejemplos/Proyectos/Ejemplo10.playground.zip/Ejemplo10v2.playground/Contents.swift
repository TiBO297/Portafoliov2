//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda
import UIKit
var venta:Double=0.00
var comision:Double=0.00
var porcentaje:Double=0.00

venta=175.45

if venta<=300.99 {
    porcentaje = 0.02
}
if venta>=301 && venta<=500.99 {
    porcentaje = 0.03
}
if venta>=501 && venta<=750.99 {
    porcentaje=0.035
}
if venta>=751 && venta<=999.99 {
    porcentaje=0.04
}
if venta>=1000 {
    porcentaje=0.045
}
comision=venta*porcentaje
print("Por una venta de \(venta) la comision es: \(comision)")
