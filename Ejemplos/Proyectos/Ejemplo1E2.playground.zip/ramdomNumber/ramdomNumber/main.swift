//
//  main.swift
//  ramdomNumber
//

import Foundation

var ramdomNumber = 1
var continueGuessing = true
var keepPlaying = true
var input = ""

while keepPlaying {
    ramdomNumber = Int (arc4random_uniform(101)) //get a ramdom number betwee 0-100
    print("The ramdom number to guess is: \(ramdomNumber)")
    while continueGuessing {
        print("Pick a number between 0 and 100")
        input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String //get keyboard input
        input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil) //strip off \n
        if let userGuess = Int(input) {
            if userGuess == ramdomNumber {
                continueGuessing = false
                print("Correct number!")
            }
            //nested if statement
            else if userGuess > ramdomNumber {
                // user guess to high
                print("ur guess is to high!")
            }
            else{
                //no reason to check if user userGuess < ramdomNumber
                print("ur guess is to low!")
            }
        }else {
            print("invalid guess, pls try again.")
        }
    }
    print("Play again? Y or N")
    input = NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String //get keyboard input
    input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    
    if input == "N" || input == "n" {
        keepPlaying = false
    }
    continueGuessing = true
}


