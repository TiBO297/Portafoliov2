//
//  impuestorenta.swift
//  claseb09102921b
//
//  Created by Development on 10/9/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation
//Metodo calculo de renta
//para mensual
//para quincenal
//para semana

//var salario:Double = 0.00
var renta:Double = 0.00


class impuestoRenta{

    func semanal(salario:Double) -> Double {
    if salario >= 0.01 && salario <= 118.00 {
        renta = 0.00
    }
    else if salario >= 118.01 && salario <= 223.81 {
        renta = (((salario - 118.00) * 0.10) + 4.42)
    }
    else if salario >= 223.82 && salario <= 509.52 {
        renta = (((salario - 223.81) * 0.20) + 15.00)
    }
    else if salario >= 509.53 {
        renta = (((salario - 509.52) * 0.30) + 72.14)
    }
    return renta
}

    func quincenal(salario:Double) -> Double{
    if salario >= 0.01 && salario <= 236.00 {
        renta = 0.00
    }
    else if salario >= 236.01 && salario <= 447.62 {
        renta = (((salario - 236.00) * 0.10) + 8.83)
    }
    else if salario >= 447.63 && salario <= 1019.05 {
        renta = (((salario - 447.62) * 0.20) + 30.00)
    }
    else if salario >= 1019.06 {
        renta = (((salario - 1019.05) * 0.30) + 144.28)
    }
    return renta
}
    func Mensual(salario:Double) -> Double {

    if salario >= 0.01 && salario <= 472.00 {
        renta = 0.00
    }
    else if salario >= 472.01 && salario <= 895.24 {
        renta = (((salario - 472.00) * 0.10) + 17.67)
        
    }
    else if salario >= 895.25 && salario <= 2038.10 {
        renta = (((salario - 895.24) * 0.20) + 60.00)
    }
    else if salario >= 2038.11 {
        renta = (((salario - 2038.10) * 0.30) + 288.57)
    }
    return renta
}

}



