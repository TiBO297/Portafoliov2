import UIKit
class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    @IBOutlet weak var txtSalario: UITextField!
    @IBOutlet weak var pickerPago: UIPickerView!
    @IBOutlet weak var labelImpuesto: UILabel!
    @IBOutlet weak var labelOpcion: UILabel!
    let pickerData = ["Mensual", "Quincenal","Semanal"]
    var objImpuesto = impuestoRenta()
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerPago.dataSource=self
        pickerPago.delegate=self}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()}
    @IBAction func calcularRenta(_ sender: UIButton) {
        var resultado = 0.00
        var vopcion:String = ""
        var valorSalarioD = 0.00
        var valorSalario:String = txtSalario.text!
        valorSalarioD=Double(valorSalario)!
        vopcion=labelOpcion.text!
        if(vopcion=="Mensual"){
            resultado=objImpuesto.Mensual(salario: valorSalarioD)}
        if(vopcion=="Quincenal"){
            resultado=objImpuesto.quincenal(salario: valorSalarioD)}
        if(vopcion=="Semanal"){
            resultado=objImpuesto.semanal(salario: valorSalarioD)}
        labelImpuesto.text = String(resultado)}
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1}
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count}
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]}
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        labelOpcion.text = pickerData[row]}
    
    

    
    
    
    
    
    
    

}

