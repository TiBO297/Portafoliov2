//
//  main.swift
//  Clase11092021AA
//
//  Created by Development on 9/11/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

var obj:calculo=calculo()
obj.v1=8
obj.v2=2
print(obj.sumar())
print(obj.restar())
print(obj.multiplicar())
print(obj.dividir())





