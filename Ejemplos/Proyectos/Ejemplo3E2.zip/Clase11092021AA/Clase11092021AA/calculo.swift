import Foundation

class calculo
{
    var v1:Int=0
    var v2:Int=0
    var error:String=""
    
    
    func sumar() -> Int
    {
        var resultado:Int=0
        resultado=v1+v2
        return resultado
    }
    
    func restar() -> Int
    {
        var resultado:Int=0
        resultado=v1-v2
        return resultado
    }
    
    func multiplicar() -> Int
    {
        var resultado:Int=0
        resultado=v1*v2
        return resultado
    }
    
    func dividir() -> Double
    {
        var resultado:Double=0
        if (v2 != 0)
        {
            resultado=Double(v1)/Double(v2)
        }else{
            error="No se puede dividir entre cero"
        }
        
        return resultado
    }
}

struct customer {
    var firstName = ""
    var lastName = ""
    var addresLine1 = ""
    var addresline2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumer = ""
    var email = ""
    var favoriteGenre = ""
}

