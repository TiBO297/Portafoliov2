//: Playground - noun: a place where people can play
//Hecho por: Bryan Exequiel Miranda 25-05082017
//Opcion de operacion puede tener valores de "S" Suma, "R" resta, "M" multiplicacion, "D" division
import UIKit
