//
//  ViewController.swift
//  clase1809
//
//  Created by Development on 9/18/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblMensaje: UILabel!
    
    @IBOutlet weak var btnCambiar: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func cambiando(_ sender: UIButton) {
        lblMensaje.text="Hola Mundo"
    }
    
}

